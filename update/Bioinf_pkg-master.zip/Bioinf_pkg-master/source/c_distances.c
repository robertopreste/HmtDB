#include <Python.h>
#include <math.h>

#define GAP '-'
#define A   'A'
#define T   'T'
#define C   'C'
#define G   'G'
#define R   'R'
#define Y   'Y'
#define N   'N'

/* Changelog:
- Aggiunto un controllo per sequenze che presentano un numero di trasversioni
  maggiore delle transizioni (sequenze random o non allineate).
  Viene Generata un'eccezione ValueError, lo stesso tipo del codice python
*/
//MANCANO UN SACCO DI CONTROLLI, usare con cautela, alla peggio va in crash
//l'interprete o la quantita' di memoria utilizzata cresce a dismisura
//(hai detto niente!)

/*----------------------------- Prototypes ----------------------------*/
// Init
PyMODINIT_FUNC initc_distances(void);
// Eventi nucleotidici
int IsTransition(const char inA, const char inB);
int IsTransversion(const char inA, const char inB);
// Distanze
static PyObject* distances_distKimura(PyObject *self, PyObject *args);
static PyObject* distances_distKimuraR(PyObject *self, PyObject *args);
static PyObject* distances_distSimple(PyObject *self, PyObject *args);
static PyObject* distances_distSimpleR(PyObject *self, PyObject *args);
/*---------------------------------------------------------------------*/

static struct PyMethodDef SiteVarMethods[] = {
    {"distKimura", distances_distKimura, METH_VARARGS,
     "Calcola la distanza di Kimura fra 2 sequenze"},
    {"distKimuraR", distances_distKimuraR, METH_VARARGS,
     "Calcola la distanza di Kimura fra 2 sequenze, usa regioni"},
    {"distSimple", distances_distSimple, METH_VARARGS,
     "Calcola la distanza semplice fra 2 sequenze"},
     {"distSimpleR", distances_distSimpleR, METH_VARARGS,
     "Calcola la distanza Semplice fra 2 sequenze, usa regioni"},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

PyMODINIT_FUNC
initc_distances(void)
{
    (void) Py_InitModule("c_distances", SiteVarMethods);
}

static PyObject*
distances_distKimura(PyObject *self, PyObject *args){

    int p, q, i, length;
    char *seq1, *seq2;
    char x, y;
    double dist, pMean, qMean;

    if (!PyArg_ParseTuple(args, "ss#", &seq1, &seq2, &length)){
        return Py_BuildValue("i", -10);
    }
    
    p = q = 0;
    
    for (i = 0; i < length; i++){
        x = seq1[i];
        y = seq2[i];
        if ( x != y ){
            if (IsTransition(x,y)){
                p++;
            }else if (IsTransversion(x,y)){
                q++;
            }
        }
    }
    
    pMean = (double)(p) / (double)(length);
    qMean = (double)(q) / (double)(length);
    
    if (1 - 2 * qMean <= 0) {
        PyErr_SetString(PyExc_ValueError, "Number of Transversions greater than the number of Trasitions");
        return NULL;
    }
    
    dist = -0.5 * log(1 - (2 * pMean) - qMean) -0.25 * log(1 - (2 * qMean));
    
    return Py_BuildValue("d", dist);

}

static PyObject*
distances_distKimuraR(PyObject *self, PyObject *args){

    int p, q, i, f, length, size, pos, end;
    char *seq1, *seq2;
    char x, y;
    double dist, pMean, qMean;
    PyObject *region, *regions;

    if (!PyArg_ParseTuple(args, "ssO", &seq1, &seq2, &regions)){
        return Py_BuildValue("i", -10);
    }
    
    p = q = length = 0;
    
    size = PyTuple_Size(regions);
    
    for (f = 0; f < size; f++){

        region = PyTuple_GetItem(regions, f);

        if (!PyArg_ParseTuple(region, "ii", &pos, &end)){
            return Py_BuildValue("i", -20);
        }
        
        length += end-pos;
        
        for (i = pos; i < end; i++){
            x = seq1[i];
            y = seq2[i];
            if ( x != y ){
                if (IsTransition(x,y)){
                    p++;
                }else if (IsTransversion(x,y)){
                    q++;
                }
            }
        }
    }
    
    
    pMean = (double)(p) / (double)(length);
    qMean = (double)(q) / (double)(length);
    
    if (1 - 2 * qMean <= 0) {
        PyErr_SetString(PyExc_ValueError, "Number of Transversions greater than the number of Trasitions");
        return NULL;
    }
    
    dist = -0.5 * log(1 - (2 * pMean) - qMean) -0.25 * log(1 - (2 * qMean));
    
    return Py_BuildValue("d", dist);

}

static PyObject*
distances_distSimple(PyObject *self, PyObject *args){

    int i, length;
    char *seq1, *seq2;
    char x, y;
    double n, dist;

    if (!PyArg_ParseTuple(args, "ss#", &seq1, &seq2, &length)){
        return Py_BuildValue("i", -10);
    }
    
    n = 0;
    
    for (i = 0; i < length; i++){
        x = seq1[i];
        y = seq2[i];
        if ( x != y ){
            n++;
        }
    }
    
    dist = n / (double)(length);
    
    return Py_BuildValue("d", dist);

}

static PyObject*
distances_distSimpleR(PyObject *self, PyObject *args){

    int n, i, f, length, size, pos, end;
    char *seq1, *seq2;
    char x, y;
    double dist;
    PyObject *region, *regions;

    if (!PyArg_ParseTuple(args, "ssO", &seq1, &seq2, &regions)){
        return Py_BuildValue("i", -10);
    }
    
    n = length = 0;
    
    size = PyTuple_Size(regions);
    
    for (f = 0; f < size; f++){

        region = PyTuple_GetItem(regions, f);

        if (!PyArg_ParseTuple(region, "ii", &pos, &end)){
            return Py_BuildValue("i", -20);
        }
        
        length += end-pos;
        
        for (i = pos; i < end; i++){
            x = seq1[i];
            y = seq2[i];
                if ( x != y ){
                n++;
                }
        }
    }
    
    
    dist = n / (double)(length);
    
    return Py_BuildValue("d", dist);

}

int IsTransition(const char inA, const char inB)
{

	switch (inA)
	{
		case A:
            if ((inB == G) | (inB == R)){ return 1; }
            break;
		case C:
            if ((inB == T) | (inB == Y)){ return 1; }
            break;
		case G:
            if ((inB == A) | (inB == R)){ return 1; }
            break;
		case T:
            if ((inB == C) | (inB == Y)){ return 1; }
            break;
		case R:
            if ((inB == A) | (inB == G)){ return 1; }
            break;
		case Y:
            if ((inB == C) | (inB == T)){ return 1; }
            break;
	}
	return 0;
}

int IsTransversion(const char inA, const char inB){

	switch (inA) {
		case A:
            if ((inB == T) | (inB == Y) | (inB == C) | (inB == N)){ return 1; }
            break;
		case G:
            if ((inB == T) | (inB == Y) | (inB == C) | (inB == N)){ return 1; }
            break;
		case R:
            if ((inB == T) | (inB == Y) | (inB == C) | (inB == N)){ return 1; }
            break;
		case C:
            if ((inB == G) | (inB == R) | (inB == A) | (inB == N)){ return 1; }
            break;
		case T:
            if ((inB == G) | (inB == R) | (inB == A) | (inB == N)){ return 1; }
            break;
		case Y:
            if ((inB == G) | (inB == R) | (inB == A) | (inB == N)){ return 1; }
            break;
        // vedi equivalente python per spiegazioni
		/*case N:
            if (inB != GAP){ return 1; }
            break;*/
	}
	return 0;
}
