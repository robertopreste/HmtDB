#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

__version__ = "1.0"
