#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste
import re
from comp import Composition
import cPickle, gzip, os

"""
Define RegEx Classes

Modulo contenente la classe che analizza allineamenti (non necessariamente
nucleotidici, ma su amminoacidi non ci ho proprio lavorato, bisogna fare delle
prove e aggiungere le necessarie funzioni/classi nel modulo delle sequenze)

Done:
    - NucRegEx should be almost done for now
    - Implementare Eccezioni Custom
    - implementare il protocollo per le sequenze ed altri (iterazione fatta,
      non sono sicuro che servano altri)
    - Eliminare le variabili/funzioni private (__var) in favore di (_var)
    - Utilizzata ora la classe Composition in comp.py (e cambiata la funzione)
ToDo:
    - Comments, explanations, etc.
    - Finalize, adding other classes/functions
    - Modificare la funzione per la generalizzazione?
"""

__deprecated__ = """analyseAlg generalizeRegEx checkRegEx compileRegEx findInSeq 
                  saveRegEx loadRegEx getNames getByName getByNameRaw 
                  getLengthRaw getLength"""

ERR_COMP_TYPE = "Must be a Composition instance defined in comp.py"
ERR_BLANK_SITE = "%s contains empty sites! will be skipped"
ERR_PARAM_REGEX = "Regex name not valid %s"
ERR_PARAM_SEQ = "Sequence not valid %s"


class CompTypeError(Exception):
    """
    Sollevata nel caso non sia data una istanza della classe
    presente nella libreria"""
    pass


class BlankSiteError(Exception):
    """
    Sollevata nel caso in cui la l'allineamento presenti un sito
    contenente solo gap (sito vuoto)
    """
    pass


class EmptyParameterError(Exception):
    """
    Sollevata nel caso un parametro non sia stato passato/vuoto,
    il messaggio di errore contiene il parametro ed il suo valore 
    """
    pass


# Regex operations on alignments
class NucRegEx(object):
    """
    Class for analysis of alignment and sequences with regex
    
    After a bunch of analyseAlg or a generalize_reg_ex and prior to
    a call to findInSeq you should use compileRegEx though it's
    not really required
    """
    MIN_LEN = 200
    _regex_list = {}
    """
    Contiene le regex nella forma name S{->} regex dove regex è una lista della
    lunghezza dell'allineamento da cui è stata generata.
    Ogni elemento della lista contiene la composizione del sito in forma di classe
    di caratteri più un eventuale ? se il sito contiene almeno un gap 
    """
    _regex_list_compiled = {}
    """
    Contiene le forme compilate delle regex, nella stessa forma di L{_regex_list}
    """
    _regex_list_compiled_regions = {}
    """
    Contiene le forme compilate delle regex, ad ogni nome (chiave) di L{_regex_list}
    corrisponde una lista di regioni da controllare
    """
    threshold = 0.15
    
    # methods used for generation of regex etc.
    def analyse_alg(self, composition, name, spos=None, epos=None):
        """
        Extract a regex from an alignment
        
        @type composition: L{Composition}
        @param composition: must be a Composition instance defined in comp.py
        @type name: string
        @param name: is associated to the regex in _regex_list
        @type spos: int
        @param spos: start position for analysis
        @type epos: int
        @param epos: end position for analysis
        
        @raise CompTypeError: nel caso in cui non sia dato un oggetto L{Composition}
        @raise BlankSiteError: nel caso uno o più siti dell'allineamento siano vuoti
        """
        if not isinstance(composition, Composition):
            raise CompTypeError(ERR_COMP_TYPE)
        sites = []
        for site in composition.get_comp_range(spos,epos):
            # string from list of all nucleotides present (excluding gaps)
            nuclist = "".join([k for k, v in site.iteritems() if v > 0 and k != "-"])
            # check if there's a gap; if true will append a ? after char class
            # 0 is false in python
            # case with more than a nucleotide
            if len(nuclist) > 1:
                if site["-"]:
                    sites.append("[%s]%c" % (nuclist, "?"))
                else:
                    sites.append("[%s]" % nuclist)
            # case with only a nucleotide
            else:
                if site["-"]:
                    sites.append("%s%c" % (nuclist, "?"))
                else:
                    sites.append(nuclist)
        while sites.count("?"):
            # alternativa per levare i siti vuoti... la fine di un incubo?!
            sites.remove("?")
        # if ''.join(sites).find('??') != -1:
        #            #la situazione si presenta sicuramente solo quando sono due siti
        #            #di seguito ad essere vuoti? non ricordo bene
        #            raise BlankSiteError(ERR_BLANK_SITE % name)
        self._regex_list[name] = sites
    analyseAlg = analyse_alg
        
    def generalize_regex(self, name, threshold=5, sub=".*?"):
        """
        Used to generalize a regular expression
        
        @attention: sostituisce la regex con lo stesso nome    
        
        a number of consecutive sites like .? >= threshold will be
        substitued by .*? as default (non greedy *)
        
        Buona idea sarebbe di usare threshold mettendo
        sub='.{,threshold}' con magari mettendo una classe di caratteri
        al posto di . (per questa cosa ci vorrebbe un nuovo metodo o parametro
        
        @type name: string
        @param name: nome della regex
        @type threshold: int
        @param threshold: se numero di siti contenenti un gap consecutivi è
                          S{>=} di threshold allora quella porzione viene sostituita
                          da sub
        @type sub: string
        @param sub: wildcard usata per sostituire più siti consecutivi
        """
        # list which will contain positions to be modified
        todo = []
        reg = self.get_by_name_raw(name)
        count = 0
        for pos, site in enumerate(reg):
            if site.find("?") == -1:
                if count >= threshold:
                    todo.append((pos - count, count))
                count = 0
            else:
                count += 1
        else:
            # this cover a case in which last nucleotide has a ? after a number of other gaps
            if site.find("?") != -1:
                pos += 1
            if count >= threshold:
                todo.append((pos - count, count))
        for pos, num in todo:
            # print ''.join(reg[pos:pos+num]),'->',''.join([sub]+['']*(num-1))
            reg[pos: pos + num] = [sub] + [""] * (num - 1)
        self._regex_list[name] = [site for site in reg if site != ""]
    generalizeRegEx = generalize_regex
    
    def generalize_regex2(self, name, threshold=5, sub=".{,%d}"):
        """
        Used to generalize a regular expression (Other Method)
        
        @attention: sostituisce la regex con lo stesso nome    
        
        a number of consecutive sites like .? >= threshold will be
        substitued by .{,%d} as default (where %d is equal to the length of
        regex to be substituted)
        
        @type name: string
        @param name: nome della regex
        @type threshold: int
        @param threshold: se numero di siti contenenti un gap consecutivi è
                          S{>=} di threshold allora quella porzione viene sostituita
                          da sub
        @type sub: string
        @param sub: wildcard usata per sostituire più siti consecutivi
        """
        # list which will contain positions to be modified
        todo = []
        reg = self.get_by_name_raw(name)
        count = 0
        for pos, site in enumerate(reg):
            if site.find("?") == -1:
                if count >= threshold:
                    todo.append((pos - count, count))
                count = 0
            else:
                count += 1
        else:
            # this cover a case in which last nucleotide has a ? after a number of other gaps
            if site.find("?") != -1:
                pos += 1
            if count >= threshold:
                todo.append((pos - count, count))
        for pos, num in todo:
            # print "".join(reg[pos:pos+num]),"->","".join([sub%num]+[""]*(num-1))
            # sostituisce lo slice calcolato
            reg[pos: pos + num] = [sub % num] + [""] * (num - 1)
        self._regex_list[name] = [site for site in reg if site != ""]
    
    def check_regex(self, name):
        """
        Checks if regex contains too much ? for its length
        return True if its ok, False otherwise
        
        @rtype: boolean
        """
        reg = self.get_by_name(name)
        val = reg.count("?") / float(len(reg))
        if val <= self.threshold:
            return False
        else:
            return True
    checkRegEx = check_regex
    
    def get_min_length(self, name):
        """
        Restituisce la lunghezza della sequenza più piccola che può
        dare un match dell"allineamento name
        """
        return len([x for x in self.get_by_name_raw(name) if "?" not in x])
    
    def check_all(self):
        """
        Check all regex with L{check_regex} and if True, remove it from internal
        list
        """
        for name in self.get_names():
            if self.check_regex(name):
                yield name
    
    def compile_regex(self, spos=0, epos=0, incr=True):
        """
        Compile all regex in a separate dictionary (it should be faster this way)
        
        Specifying spos and epos make it possible to use only a region of the
        alignment instead of the full length without reanalysing the alignment
        
        @type spos: int
        @param spos: start position for compilation
        @type epos: int
        @param epos: end position for compilation
        """
        if not incr:
            self._regex_list_compiled = {}
        if len(self._regex_list) == 0: 
            return  # no regex no compile
        
        self._regex_list_compiled = {}
        
        for name, reg in self._regex_list.iteritems():
            if epos == 0:
                self._regex_list_compiled[name] = re.compile("".join(reg))
            else:
                self._regex_list_compiled[name] = re.compile("".join(reg[spos:spos+epos]))
    compileRegEx = compile_regex
    
    def compile_regex_regions(self, window=20, step=5):
        """
        Compila tutte le possibili "regioni" da cercare poi nella sequenza
        
        l'ultima finestra verrà esclusa se <= L{step}
        """
        # inizializza il dizionario
        self._regex_list_compiled_regions = {}
        for name in self._regex_list:
            rex_len = self.get_length_raw(name)
            if rex_len > window:
                self._regex_list_compiled_regions[name] = []
                
                # aggiunge tutti le possibili "regioni" alla lista
                for pos in xrange(0, rex_len-window, step):
                    raw = self.get_by_name_raw(name)[pos:pos+window]
                    try:
                        compiled = re.compile("".join(raw))
                    except:
                        raise BlankSiteError("controllare che l'allineamento "
                                             "%s non contenga siti vuoti" %
                                             name)
                    self._regex_list_compiled_regions[name].append(compiled)
    
    def find_in_seq(self, name, seq):
        """
        Search for a RegEx in a sequence string
        
        @type name: string
        @param name: is associated to the regex in _regex_list
        @type seq: string
        @param seq: is a string containing a nucleotide sequence
        
        @rtype: None or MatchObject
        Restituisce None se non c'e' match, altrimenti 
        
        @raise EmptyParameter: nel caso i parametri non siano stati impostati
        
        @note: forse è il caso di creare un mio oggetto per il match
        """
        if not seq:
            raise EmptyParameterError(ERR_PARAM_SEQ % str(seq))
        if not name in self._regex_list:
            raise EmptyParameterError(ERR_PARAM_REGEX % str(name))
        # compiled regex used by default
        if len(self._regex_list_compiled) != len(self._regex_list):
            # prima sollevava un'eccezione, tantovale ricompilare tutto
            # automaticamente
            self.compile_regex(incr=False)
        matched = self._regex_list_compiled[name].search(seq)
        # matched is None if regex is not found in seq
        return matched
    
    findInSeq = find_in_seq
    
    def find_in_seq_regions(self, name, seq):
        """
        @rtype: tuple
        @return: il primo valore è il numero di match, il secondo il numero di
                 regioni
        """
        if not seq:
            raise EmptyParameterError(ERR_PARAM_SEQ % str(seq))
        if name not in self._regex_list_compiled_regions:
            raise EmptyParameterError(ERR_PARAM_REGEX % str(name))
        count = 0
        for rex in self._regex_list_compiled_regions[name]:
            if rex.search(seq):
                count += 1
        return count, len(self._regex_list_compiled_regions[name])
    
    # load-save regex dictionary
    def save_regex(self, fname):
        """
        Salva la lista di regex in un file
        
        @type fname: string
        @param fname: nome del file
        
        @note: se l'estensione del file è gz, verrà compresso
        """
        if os.path.splitext(fname)[1] == ".gz":
            fh = gzip.open(fname, "wb")
        else:
            fh = open(fname, "wb")
        cPickle.dump(self._regex_list, fh, cPickle.HIGHEST_PROTOCOL)
        fh.close()
    
    saveRegEx = save_regex
    
    def load_regex(self, fname):
        """
        Carica la lista di sequenze da file.
        Preferibilmente compilare le regex dopo il caricamento
        
        @type fname: string
        @param fname: nome del file
        
        @note: se l'estensione del file è gz, verrà considerato compresso 
        """
        if os.path.splitext(fname)[1] == ".gz":
            fh = gzip.open(fname, "rb")
        else:
            fh = open(fname, "rb")
        self._regex_list = cPickle.load(fh)
        fh.close()
    
    loadRegEx = load_regex 
    
    # various getters
    # leviamo la convenzione java getN ecc. verranno levate alla versione 1.0
    # comunque per ora lasciamo degli alias
    def get_names(self, regions=False, min_len=None):
        """
        Return all regex names

        se min_len viene specificato, verranno restituite tutte le sequenze
        hanno una lunghezza minima maggiore od uguale al valore dato.
        
        @rtype: list
        @return: regex names
        """
        if regions:
            rex_list = self._regex_list_compiled_regions
        else:
            rex_list = self._regex_list
        if min_len:
            rex_list = [x for x in rex_list if self.get_min_length(x) >= min_len]
        for name in rex_list:
            yield name
    getNames = get_names
    
    def get_by_name(self, name):
        """
        Get regex ready for compilation
        
        @rtype: string
        @return: regex
        """
        return "".join(self._regex_list[name])
    getByName = get_by_name
    
    def get_by_name_raw(self, name):
        """
        Get regex as a list of sites (ATTENZIONE!)

        @attention: Ritorna l'istanza della lista di siti che rappresenta la regex
                    serve/serviva piu' che altro per debug, quindi se si vuole solo
                    utilizzare questa lista conviene utilizzare la funzione builtin list()
                    per avere una copia della lista ritornata.
        
        @note: In realta' me n'ero dimenticato ma serve anche al metodo che generalizza
               le regex
        
        @rtype: list
        @return: regex 
        """
        return self._regex_list[name]
    getByNameRaw = get_by_name_raw
    
    def get_length(self, name):
        """
        Get length of regex ready for compilation
        @type name: string
        @param name: nome della regex
        """
        return len("".join(self._regex_list[name]))
    getLength = get_length
    
    def get_length_raw(self, name):
        """
        Get length regex as a list of sites - equals source alignment length
        @type name: string
        @param name: nome della regex
        """
        return len(self._regex_list[name])
    getLengthRaw = get_length_raw
    
    def __len__(self):
        """
        Used by builtin len() to get length of object

        Simply return number of regex in self._regex_list
        
        @rtype: int
        @return: regex list length
        """
        return len(self._regex_list)
    
    def __iter__(self):
        """
        Restituisce i nomi delle regex
        
        @rtype: generator
        @return: regex names
        """
        for item in self._regex_list:
            yield item

