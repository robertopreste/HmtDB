#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste
import csv

"""
Done:
    - Tutto funziona(va)
    - Cambiate le due funzioni di output per utilizzare la classe che contiene la
        composizione, invece del vecchio metodo (Allineamento che la contiene),
        dovrebe essere indolore (spero)
"""

from utils import autoprop
from events import isTransition, isTransversion, isAmbiguity
from array import array
import distances

__deprecated__ = "genRelativePos"


def gen_relative_pos(ref, rel):
    """
    Genera il dizionario delle sequenze relative

    Presa una sequenza di riferimento e la sua corrispettiva allineata
    produce un dizionario in cui ad ogni posizione della sequenza allineata
    viene associata la corrispondente posizione della sequenza originale;
    nel caso in cui non ci sia corrispondenza, viene utilizzata l'ultima
    posizione avente una corrispondenza a cui viene aggiunto un numero
    indicante la distanza della posizione dall'ultima nota.

    Es:
    seq originale: CGTGT
    seq allineata: C-GTG--T
    A    O
    1 -> 1
    2 -> 1.1
    3 -> 2
    4 -> 3
    5 -> 4
    6 -> 4.1
    7 -> 4.2
    8 -> 5
    """
    posRel = 0
    posRef = 0
    gapn = 0
    seqLen = len(rel)
    positions = {}
    while posRel < seqLen:
        try:
            c_ref = ref[posRef]
        except IndexError:
            c_ref = "0"
        c_rel = rel[posRel]
        if c_ref == c_rel:
            positions[posRel + 1] = str(posRef + 1)
            posRel += 1
            posRef += 1
            gapn = 0
        elif c_ref != c_rel:
            # non corrispondenza tra le due sequenze (gap)
            gapn += 1
            positions[posRel + 1] = "%d.%d" % (posRef, gapn)
            posRel += 1
    return positions


genRelativePos = gen_relative_pos


class Variability(object):
    """
    Classe che calcola la variabilita' di una sequenza

    Questa classe ha una corrispondente scritta in C e il coomportamento
    e' identico (e' possibile utilizzare l'una o l'atra)

    La scelta di utilizzare una classe che contiene la lista dei valori
    di variabilita' e' dovuta al fatto che nelle precedenti prove, si e'
    visto che la maggior parte del tempo calcolo e' perso nel sommare i
    valori di variabilita', per cui utilizzando un array fisso interno
    velocizza il tutto (la versione C attuale e' il doppio piu' veloce
    del vecchio programma)
    """
    gap = 0.0
    transition = 1.0
    transverion = 2.0
    ambiguity = 0.1
    
    def reset_values(self, seqLen, gap=0.0, transition=1.0, transversion=2.0, ambiguity=0.1):
        """
        Reimposta tutti i valori al loro default.

        E' necessario indicare la lunghezza del array
        """
        self.gap = gap
        self.transition = transition
        self.transverion = transversion
        self.ambiguity = ambiguity
        self.__gaps = set()
        self.__rates = array("d", [0.0 for x in xrange(seqLen)])
    
    def __getRates(self):
        """
        Assicura che il comportamento sia lo stesso tra
        versione C e Python (restituisce una copia dell'array)
        """
        return self.__rates.tolist()
    rates = property(__getRates)
    
    def __getGaps(self):
        """
        Assicura che il comportamento sia lo stesso tra
        versione C e Python (restituisce una copia dell'array)
        """
        return self.__gaps.copy()
    gaps = property(__getGaps)
    
    def varSequence(self, seq1, seq2, pos, end, dist, wgaps=1):
        """
        Calcola la variabilita' di due sequenze

        Aggiunge all'array interno i valori calcolati

            - seq1, seq2: le due sequenze
            - pos: la posizione d'inizio del calcolo (inclusa)
            - end: la posizione di fine (non inclusa)
            - dist: la distanza delle due sequenze
            - wgaps: indica se contare le posizioni con gap (serve al chiamante)
        """
        fTrs = isTransition
        fTsv = isTransversion
        fAmb = isAmbiguity
        gaps = self.__gaps
        var = self.__rates
        gap = self.gap
        trs = self.transition
        tsv = self.transverion
        amb = self.ambiguity
        # corretto il loop da xrange(end-pos) al presente
        for cpos in xrange(pos, end):
            x = seq1[cpos]
            y = seq2[cpos]
            if x == y or x == "-" or y == "-" or x == "N" or y == "N":
                var[cpos] += gap / dist
                if wgaps:
                    if x != y:
                        gaps.add(cpos)
            elif fTrs(x, y):
                var[cpos] += trs / dist
            elif fTsv(x, y):
                var[cpos] += tsv / dist
            elif fAmb(x, y):
                var[cpos] += amb / dist


def out_classic(composition, rates, fname, andPos=None, exp=False):
    """
    Produce un file identico al vecchio sitev

    rates: i tassi in input
    fname: nome del file di output
    andPos: il dizionario contenente le posizioni relative
    exp: se usare valori esponenziali
    """
    # outString = '%%8s             %%.3%c                    %%s    %%.1f    %%.1f    %%.1f    %%.1f    %%.1f\n' % ('e' if exp else 'f')
    outString = "%%8s\t%%.3%c\t%%s\t%%.6f\t%%.6f\t%%.6f\t%%.6f\t%%.6f\n" % ("e" if exp else "f")
    f = open(fname, "w")
    for x in range(26):
        f.write("niente\n")
    f.write("=" * 75 + "\n")
    # f.write('  Site         Variability     nucleotide type  %A    %C    %G    %T    %-\n')
    f.write("Site\tVariability\tnucl_type\t%A\t%C\t%G\t%T\t%-\n")
    f.write("=" * 75 + "\n\n")
    for pos, comp in enumerate(composition):
        a = comp["A"] * 100
        c = comp["C"] * 100
        g = comp["G"] * 100
        t = comp["T"] * 100
        gp = abs(100.0 - a - c - g - t)
        f.write(outString % (andPos[pos + 1] if andPos else str(pos + 1), 
                             0.0 if gp == 100.0 else rates[pos], 
                             "".join([key for key, value in comp.iteritems() if value > 0]), 
                             a, c, g, t, gp))
    f.close()


def out_delimited(composition, rates, fname, andPos=None, delimiter="\t", exp=False):
    """
    Crea un file delimitato da tab (o ',' per avere un csv) con la variabilità nucleotidica.

    :param composition: composizione nucleotidica
    :param rates: tassi in input
    :param fname: output file name
    :param andPos: dizionario con posizioni relative
    :param delimiter: default tab
    :param exp: default False
    :return: file <fname>.csv
    """

    f = open(fname, "w")
    f.write(delimiter.join(("site", "variability", "nucl_type", "%A", "%C", "%G", "%T", "%-", "%others")) + "\n")
    for pos, comp in enumerate(composition):
        a = round(comp["A"] * 100, 8)
        c = round(comp["C"] * 100, 8)
        g = round(comp["G"] * 100, 8)
        t = round(comp["T"] * 100, 8)
        if exp:
            flag = "%e"
        else:
            flag = "%f"
        # others_names = set(comp.keys()) - set(["A", "C", "T", "G", "-"])
        others_names = set(comp.keys()) - {"A", "C", "G", "T", "-"}
        others = round(sum([comp[x] for x in others_names]) * 100, 8)
        gp = round(abs(100.0 - a - c - g - t - others), 8)
        f.write(delimiter.join((str(andPos[pos + 1]) if (andPos and (pos + 1) in andPos) else str(pos+1),
                                flag % (0.0 if gp == 100.0 else rates[pos]),
                                "".join([str(key) for key, value in comp.iteritems() if value > 0]), 
                                str(a), str(c), str(g), str(t), str(gp), str(others))) + "\n")
    f.close()


class SiteVar(object):
    """
    Si occupa di calcolare la variabilita' utilizzando le classi/funzioni
    definite
    
    Questa bestiaccia permette di utilizzare una diversa funzione per il calcolo
    delle distanze o della variabilita', e di personalizzare un po' tutto il
    calcolo
    
    Cose come diverse classi per il calcolo della variabilita' o di regioni che
    siano diverse da quelle usate da noi per il mitocondrio (dloop/coding) o
    anche la non normalizzazione dei dati non sono praticamente esposte nel tool
    a riga di comando.
    """
    __metaclass__ = autoprop
    
    def __init__(self):
        super(SiteVar, self).__init__()
    
    def _set_alg(self, alg):
        """
        Alignment to be processed

        Must be an alignment instance from the library"""
        self._alg = alg
        # imposta un'unica regione comprendente l'intero allineamento
        # e tutte le sequenze presenti
        self._regions = [(0, alg.seq_len, True)]
    
    def _get_alg(self):
        return self._alg
    
    def set_dist_type(self, dist_type=distances.distKimuraR):
        """Imposta la funzione da utilizzare per la distanza"""
        self._dist_type = dist_type
    
    def set_var_type(self, var_type=Variability):
        """Imposta il tipo di classe da usare per la variabilita'"""
        self._variability = var_type()
    
    def set_out_type(self, out_type=out_delimited):
        """Funzione per generare l'output"""
        self._out_type = out_type
    
    def set_weights(self, gap=0.0, transition=1.0, transversion=2.0, ambiguity=0.1):
        """per impostare i pesi"""
        self._gap = gap
        self._transition = transition
        self._transversion = transversion
        self._ambiguity = ambiguity
    
    def _set_regions(self, regions):
        """ Set specific regions of the alignment to be processed

            Internally regions must be a Tuple of Tuple
            ( (beg, end, all), ... ), however passed regions can
            be any iterable (because this function convert it
            to a tuple via __builtin__ tuple())

            Notes for each iterable element:

            beg, end must be the same used for a slice

            the tuple can be of 3 element indicating a single
            portion of the sequences
            (beg, end, all)
            OR
            a 5 elements tuple which indicate a single region
            consisting of two portion of the sequences
            (beg1, end1, beg2, end2, all)

            last element of tuple indicate on which set
            (only complete or all sequences) analysis will
            be done True->all sequences, False->only complete
            sequences"""
        if not isinstance(regions, (tuple, list)) or len(regions) == 0:
            raise TypeError, "Must be a tuple or list with at least one element"
        self._regions = tuple(regions)
    
    def _get_regions(self):
        """Return regions list"""
        return self._regions
    
    def calcTuples(self, seq_list=None):
        """
        Generates a set of tuples (x,y)

        It uses a generator to lower memory requirements.

        The maximum number of tuples returned is equal to
        the length of the alignment
        It goes like this:
        N = alignment length
        N, N-1, N-2, ... , N-(N-1), 1
        """
        if not seq_list:
            seqList = [x for x in range(0, len(self.alg))]
        for x in seq_list[:-1]:
            tuples = set()
            for y in seq_list[seq_list.index(x)+1:]:
                tuples.add((x, y))
            yield tuples
    
    def check_seqs(self):
        """
        Makes two sets of sequences: partials and completes

        It checks if a sequence starts and ends with a set
        number of gaps (default 50) at 5' and 3'

        This is used for analysis on mithocondrial sequences
        in which DLoop is absent and used only on coding portion
        analysis
        """
        gapnumber = getattr(self, "gapnumber", 50)
        exclude = getattr(self, "exclude", None)
        alg = self.alg
        completes = set()
        partials = set()
        for pos, seq in enumerate(alg):
            # perche' e' un array ora la sequenza
            if seq[0:gapnumber] + seq[-gapnumber:] == array("c", "-" * gapnumber * 2):
                partials.add(pos)
            else:
                completes.add(pos)
        # se esiste una sequenza marcata da escludere la toglie
        if exclude in completes:
            completes.remove(exclude)
        elif exclude in partials:
            partials.remove(exclude)
        self.comp_seqs = completes
        self.part_seqs = partials
    
    def run_analysis(self):
        """Avvia l'analisi dell'allineamento"""
        # mancano i check sulla validita' dei dati (alineamento, e altro)

        # di default wgaps e' attivato, il contrario per le callback
        wgaps = getattr(self, "wgaps", True)
        callback = getattr(self, "callback", None)
        self.check_seqs()
        dstf = self._dist_type
        varf = self._variability.varSequence
        alg = self._alg
        self._variability.reset_values(alg.seq_len, self._gap, self._transition, self._transversion, 
                                       self._ambiguity)
        # la distanza media serve nel caso si voglia aggiungere alla variabilita'
        # di un sito che presenta almeno un gap 2/distMean
        distMean = {}
        for region in self.regions:
            distMean[region] = {"Count": 0, "Sum": 0}
        for region in self.regions:
            if callback:
                callback(region)
            # controlla se usare il le sequenze complete o quelle parziali
            # per la regione da esaminare
            if region[-1]:
                seq_list = list(self.comp_seqs.union(self.part_seqs))
            else:
                seq_list = list(self.comp_seqs)
            distSum = distCount = 0
            if len(region) == 3:
                rg = ((region[0], region[1]), )
            else:
                rg = ((region[0], region[1]), (region[2], region[3]))
            for tuples in self.calcTuples(seq_list):
                for x, y in tuples:
                    # per le versioni python si potrebbero usare direttamente
                    # gli array contenenti le sequeneze, questo cambia se
                    # si usa la versione in c perche' accetta solo stringhe
                    # non credo mi convenga uccidermi per questa maggiore
                    # "pulizia"
                    dist = dstf(str(alg[x]), str(alg[y]), rg)
                    # nel caso di errori viene dato un valore minore di zero
                    # e il caso di una distanza 0 ci darebbe un errore
                    # di divisione per zero
                    # nel caso la distanza sia di Kimura, e il numero di trasversioni
                    # supera il numero di transizioni, viene sollevata un'eccezione
                    if dist > 0:
                        # DEBUG: per fa stampare a schermo delle distanze che interessano
                        # if x in (9,140) or y in (9,140):
                        #     print x,y,dist 
                        # DEBUG
                        distMean[region]["Sum"] += dist
                        distMean[region]["Count"] += 1
                        for pos, end in rg:
                            varf(str(alg[x]), str(alg[y]), pos, end, dist, wgaps)
        # restituisce la lista dei valori di variabilità
        vara = self._variability.rates
        for region in self.regions:
            if len(region) == 3:
                rg = [(region[0], region[1])]
            else:
                rg = [(region[0], region[1]), (region[2], region[3])]
            # aggiunta di 2/distMean se il sito presenta almeno un gap
            if wgaps:
                # questo cambia se si usa la versione in c
                # che usa una funzione per resituire l'array interno
                gaps = self._variability.gaps
                dstMean = float(distMean[region]["Sum"]) / distMean[region]["Count"]
                for pos, end in rg:
                    for cpos in xrange(pos, end):
                        if cpos in gaps:
                            vara[cpos] += 2 / dstMean
            # ----------------------------------------------------
            # normalizzazione dei dati
            # ----------------------------------------------------
            # prima il calcolo del massimo questo loop supporta
            # regione composte da piu' di due sottosequenze
            normalize = getattr(self, "normalize", True)
            if normalize:
                maxRate = []
                for pos, end in rg:
                    maxRate.append(max(vara[pos:end]))
                maxRate = max(maxRate)
                # normalizzazione
                for pos, end in rg:
                    for cpos in xrange(pos, end):
                        vara[cpos] = vara[cpos] / maxRate
        self.rates = vara

