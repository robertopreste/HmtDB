#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste
from events import isTransition, isTransversion
from array import array


class TabTorCln(object):
    ref_seq = 0
    
    def cln_create(self, clean=True):
        """
        Crea il dizionario che contiene le frequenze escludendo quella di riferimento

        Nel caso clean sia False, viene assegnata ad ogni sequenza dell'allineamento
        la frequenza 1 a prescindere che sia o meno vero
        """
        # levo il gruppo che contiene sequenze identiche alla sequenza di riferimento
        if clean:
            self.freqs = dict([(lst[0], len(lst)) for lst in self.alg.get_duplicates() if self.ref_seq not in lst])
        else:
            # per escludere le sequenze identiche alla sequenza di riferimento
            for lst in self.alg.get_duplicates():
                if self.ref_seq in lst:
                    ref_group = set(lst)
            allseq = set(range(len(self.alg))) - ref_group
            self.freqs = dict([(x, 1) for x in allseq])
    
    def tab_create(self):
        """
        Crea il tabellone, se non trova il dizionario con le frequenze,
        richiama clnCreate con i parametri di default
        """
        try:
            len(self.freqs)
        except AttributeError:
            self.cln_create()
        if isinstance(self.ref_seq, (int, long)):
            seq = self.alg[self.ref_seq].seq
        else:
            raise ValueError("External reference sequence is not supported")
        tab = []
        # si costruisce prima aggiungendo tutti i siti dell'allineamento
        for idx in self.freqs:
            seq1 = self.alg[idx].seq
            a = array("c")
            for x, y in zip(seq, seq1):
                if x != y:
                    if x == "-":
                        # inserzione
                        a.append("i")
                    elif y == "-":
                        # delezione D e' una ambiguita' per cui la d minuscola
                        # indica una delezione
                        a.append("d")
                    else:
                        # diverso
                        a.append(y)
                else:
                    # uguale
                    a.append("-")
            tab.append(a)
        # posizioni dell'allineamento
        positions = range(len(seq))
        # fase in cui vengono cancellati i siti in cui non ci sono variazioni
        delsites = []
        # costruzione di una lista di posizioni da cancellare
        # si procede al contrario per ovvi motivi
        for pos in reversed(positions):
            keep = False
            for s in tab:
                if s[pos] != "-":
                    keep = True
                    break
            if not keep:
                delsites.append(pos)
        # sequenza per sequenze si cancellano i siti
        for s in tab:
            for pos in delsites:
                del s[pos]
        self.tab = tab
        # si cancellano dalla lista delle posizioni quelle
        # che sono state tolte dal tabellone
        # ------
        # reversed perche' cosi' trova prima i siti da togliere
        # un niente (forse) piu' veloce, nient'altro
        for pos in reversed(delsites):
            positions.remove(pos)
        positions.sort()
        self.pos = positions
        # si produce una sequenza di riferimento che sia uguale
        # (per numero e posizione dei siti a quelle del tabellone
        rseq = list(seq)
        for pos in delsites:
            del rseq[pos]
        self.rseq = "".join(rseq)
    
    def tab_write(self, fname, n_sites=0, sortpos=True, sortmax=True, in_rel_pos=None):
        """
        Scrive il file tab creato

        Parametri:
        
            - fname:      nome del file in cui scrivere
            - n_sites:    il numero di siti da utilizzare nel file tab, usare 0 per scrivere tutti i valori
            - in_rel_pos: per passare un dizionario contente le posizioni relative

        Solo per usare tabReduce:
    
            - sortpos: ordinare per posizione (True) o per variabilita' (False)
            - sortmax: ordinare dal piu' grande al piu' piccolo (True) o il contrario
        """
        if not hasattr(self, "tab"):
            self.tab_create()
        if n_sites <= 0 or n_sites > len(self.tab[0]):
            tab = self.tab
            pos = self.pos
            rseq = self.rseq
        else:
            tab, pos, rseq = self.tab_reduce(n_sites, sortpos, sortmax)
        f = open(fname,"w")
        f.write(";")
        if in_rel_pos:
            f.write(";".join([in_rel_pos[x + 1] for x in pos]) + "\n")
        else:
            f.write(";".join([str(x + 1) for x in pos]) + "\n")
        if isinstance(self.ref_seq, (int, long)):
            rname = self.alg[self.ref_seq].name
        else:
            rname = self.ref_seq["name"]
        f.write("%s;" % rname)
        f.write(";".join(rseq) + "\n")
        for idx, seq1 in zip(self.freqs, tab):
            f.write("%s;" % self.alg[idx].name)
            f.write(";".join(seq1) + "\n")
        f.close()
    
    def tab_reduce(self, n_sites=255, sortpos=True, sortmax=True):
        """
        Riduce il numero di posizioni nel file tab utilizzando i valori di
        variabilita' contenuti in in_rates
        """
        rates = []
        in_rates = getattr(self, "in_rates")
        if not in_rates:
            raise ValueError("No rates specified")
        for pos, rate in enumerate(in_rates):
            if rate > 0:
                rates.append((rate, pos))
        rates.sort(reverse=sortmax)
        rates = rates[:n_sites]
        positions = [pos for rate, pos in rates]
        if sortpos:
            positions.sort()
        tab = []
        for seq in self.tab:
            a = array("c")
            for pos in positions:
                a.append(seq[self.pos.index(pos)])
            tab.append(a)
        rseq = array("c")
        for pos in positions:
            rseq.append(self.rseq[self.pos.index(pos)])
        return tab, positions, rseq
    
    def tor_create(self, fname, in_rel_pos=None):
        """
        Creazione del file tor
        """
        try:
            len(self.tab)
        except AttributeError:
            self.tab_create()
        freqs = self.freqs
        tab = self.tab
        pos = self.pos
        rseq = self.rseq
        trs = isTransition
        trv = isTransversion
        f = open(fname, "w")
        for idx, seq in zip(freqs, tab):
            changes = []
            for x, y, n in zip(rseq, seq, pos):
                if in_rel_pos:
                    n = in_rel_pos[n + 1]
                else:
                    n = str(n + 1)
                if trs(x, y):
                    changes.append("+%s" % (n, ))
                elif trv(x, y):
                    changes.append("+%s%c" % (n, y))
            f.write("%s\n%s\n%d\n" % (self.alg[idx].name, " ".join(changes), freqs[idx]))
        f.close()
