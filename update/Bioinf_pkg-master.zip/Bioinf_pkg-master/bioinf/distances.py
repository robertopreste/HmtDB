#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

"""
Contiene le funzioni che calcolano le distanze fra 2 sequenze.

Tipi di funzioni per il calcolo delle distanze:
===============================================

Ci sono due tipi di funzioni:
    1. le funzioni che prendono in input 2 sequenze allineate
    2. quelle che calcolano la distanza basandosi non su tutta la lunghezza delle
       sequenze

Le seconde permettono di specificare una porzione della sequenza (organizzata
anche in più porzioni)

Una "regione" è una lista (o tupla) di tuple nella forma quindi: C{[ (n, m), .. (nn, mm) ]}
La tupla nella (n,m) la definiamo "porzione" della regione dove C{n} rappresenta il
limite inferiore ed C{m} il limite superiore dello slice secondo le specifiche
python (limite inferiore incluso e il superiore escluso).

La regione "tipo" per cui è stata pensata tale soluzione è il dloop, che nelle
sequenze e formato da due porzioni del genoma mitocondriale fra le quali si trova
la coding. tipicamente il dloop come regione è rappresentato da qualcosa tipo:
C{[ (0, 500), (16000, 16800) ]} (2 porzioni) a seconda dell'allineamento, mentre
la coding da C{[ (500, 16000) ]} (1 porzione), quindi nel calcolo della distanza
del dloop viene esclusa la coding e viceversa.

Il numero di porzioni è M{N} e non ha praticamente limiti se non quelli fisici di
memoria utilizzata (comunque bassa credo)

Non è "obbligatorio" la definizione di funzioni funzioni di distanza che tengano
conto delle regioni, ma ci sono classi che le richiedono, come L{SiteVar}

SiteVar:
--------
    Ogni funzione che deve essere usata in L{SiteVar} deve avere un'equivalente
    che supporti le regioni. Non gli serve una funzione per il calcolo sull'intera
    sequenza.

    script:
    ~~~~~~~
        Per lo script sitevar, se si vuole includere la funzione tra quelle utilizzabili,
        bisogna che:
            1. il nome della funzione e un nome che la identifichi vengano messi nel
               dizionario L{dists} e
            2. che la funzione che supporti le regioni abbia nome identico ma con suffisso R,
               es. distSome S{->} distSomeR  

Modulo c_distances:
===================

Le funzioni definite in quel modulo hanno lo stesso comportamento delle equivalenti
scritte in python (c'è un test nella suite per questo), la differenza è che sono
scritte in C, usando le API che python mette a disposizione per creare estensioni
e la possibilità di compilarle con ottimizzazioni più o meno spinte (che danno
risultati diverse da quelle in python nei miei test dopo la 12° cifra decimale) 

Note per l'uso:
---------------

    - In generale le funzioni sono di circa 2 ordini di grandezza più veloci delle
      equivalenti scritte in python.
    - Le sequenze passate DEVONO essere stringhe, mentre le funzioni python accettano
      qualunque oggetto che rispetti il protocollo delle sequenze e che ad ogni
      iterazioni restituisca una stringa da passare ai controlli di transizione
      e trasversione

"""
from events import isTransition, isTransversion
from math import log


def distKimura(seq1, seq2):
    """
    Calculates Kimura distance of two sequence
    
    @type seq1: string
    @param seq1: sequenza nucleotidica
    @type seq2: string
    @param seq2: sequenza nucleotidica
    """
    tsv = isTransversion
    trs = isTransition
    p = 0
    q = 0
    seqLen = float(len(seq1))
    for x, y in zip(seq1, seq2):
        if x != y:
            if trs(x, y):
                p += 1
            elif tsv(x, y):
                q += 1
    
    # media delle transizioni/trasversioni
    pMean = p / seqLen
    qMean = q / seqLen
    
    # formula a 2 parametri di Kimura
    if (1 - 2 * qMean) <= 0:
        raise ValueError("Number of Transversions greater than the number of Trasitions")
    dist = -0.5 * log(1 - (2 * pMean) - qMean) - 0.25 * log(1 - (2 * qMean))
    return dist


def distKimuraR(seq1, seq2, region):
    """
    Calculates Kimura distance of two sequence
    
    accept a list of tuples like [(pos1, end1), ..., (posN, endN)]
    pos and end must be the same values used in a slice
    
    @type seq1: string
    @param seq1: sequenza nucleotidica
    @type seq2: string
    @param seq2: sequenza nucleotidica
    @type region: sequence
    @param region: sequenza di tuple definenti slice della regione interessata 
    """
    tsv = isTransversion
    trs = isTransition
    p = q = seqLen = 0
    
    def sumEvents(pos, end):
        p = q = 0
        for cpos in xrange(pos, end):
            x = seq1[cpos]
            y = seq2[cpos]
            if x != y:
                if trs(x, y):
                    p += 1
                elif tsv(x, y):
                    q += 1
        return p, q
    
    for pos, end in region:
        seqLen += end-pos
        _p, _q = sumEvents(pos, end)
        p += _p
        q += _q
    
    # media delle transizioni/trasversioni
    pMean = p / float(seqLen)
    qMean = q / float(seqLen)
    
    # formula a 2 parametri di Kimura
    if (1 - 2 * qMean) <= 0:
        raise ValueError("Number of Transversions greater than the number of Trasitions")
    dist = -0.5 * log(1 - (2 * pMean) - qMean) - 0.25 * log(1 - (2 * qMean))
    return dist


def distSimple(seq1, seq2):
    """
    Calculates a simple distance of two sequence
    
    @type seq1: string
    @param seq1: sequenza nucleotidica
    @type seq2: string
    @param seq2: sequenza nucleotidica
    """
    n = 0
    seqLen = len(seq1)
    for x, y in zip(seq1, seq2):
        if x != y:
            n += 1
    # formula semplice
    return n / float(seqLen)


def distSimpleR(seq1, seq2, region):
    """
    Calculates a simple distance of two sequence
    
    accept a list of tuples like [(pos1, end1), ..., (posN, endN)]
    pos and end must be the same values used in a slice
    
    @type seq1: string
    @param seq1: sequenza nucleotidica
    @type seq2: string
    @param seq2: sequenza nucleotidica
    @type region: sequence
    @param region: sequenza di tuple definenti slice della regione interessata
    """
    n = seqLen = 0
    
    def sumEvents(pos, end):
        n = 0
        for cpos in xrange(pos, end):
            x = seq1[cpos]
            y = seq2[cpos]
            if x != y:
                n += 1
        return n
    
    for pos, end in region:
        seqLen += end-pos
        _n = sumEvents(pos, end)
        n += _n
    # formula semplice
    return n / float(seqLen)


# Dizionario contenente i nomi delle distanze e i nomi delle rispettive funzioni
dists = {"kimura": "distKimura",
         "simple": "distSimple"}
