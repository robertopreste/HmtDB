# Bioinf_pkg  

### Originally written by Francesco Rubino, edited by Roberto Preste  
### Version 1.0  


## Installation  

### Virtualenv  
Install a python 2.7 virtualenv:  
`virtualenv -p python2.7 venv`  
Activate the virtualenv:  
`source venv/bin/activate`  

### Pyrex
Install the Pyrex package, after downloading it:  
`wget http://www.cosc.canterbury.ac.nz/greg.ewing/python/Pyrex/Pyrex-0.9.9.tar.gz`  
`tar zxvf Pyrex-0.9.9.tar.gz`  
`cd Pyrex-0.9.9/`  
`python setup.py install`  
`cd ../`  

### Bioinf_pkg  
First build the Bioinf package, then install it:  
```
python setup.py build 
python setup.py install
```  

Deactivate the virtualenv:  
`deactivate`  
