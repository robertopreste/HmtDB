#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
import bioinf.distances as PyDists
from bioinf.c_distances import distKimura, distKimuraR, distSimple, distSimpleR
from bioinf.utils import genRandSeq

"""
nel confronto tra distanze generate dal codice python e C entrano in gioco
le ottimizzazioni del compilatore che sono state usate per la distribuzione
di Python usata e quelle utilizzate nella compilazione della libreria.
se il test fallisce nel confrontare i risultati utilizzare un valore piu'
basso per completare il test senza errori.
Da notare che 14 posizioni decimale e' un valore di precisione forse
"eccessivo" per lo scopo del calcolo 8-9 sono "sufficienti".
14 sono le posizioni identiche nel confronto che ho fatto io, forse dovuto
all'uso delle SSE (specificate da me) dal compilatore gcc 4.2.1 su Linux
"""
minPos = 14


class TestCDistances(unittest.TestCase):
    def setUp(self):
        self.seq1 = "ATACAGGACTTATAACTAGT"
        self.seq2 = "TTCAGGGATGAGTGCGCACT"
        self.region = ((0, len(self.seq1) // 2), (len(self.seq1) // 2, len(self.seq1)))
    
    def test_01_distKimura(self):
        """
        Controlla che i risultati siano confrontabili
        tra la funzione scritta in Python e quella
        scritta in C per un minimo di minPos
        """
        Cdist = distKimura(self.seq1, self.seq2)
        Pdist = PyDists.distKimura(self.seq1, self.seq2)
        self.assertAlmostEqual(Cdist, Pdist, minPos)
    
    def test_03_distKimuraR(self):
        """
        Le funzioni che calcolano la distanza per regioni
        se calcolate sul totale della sequenza (2 regioni
        che sommate danno l'intera sequenza) devono dare
        un risultato identico alla funzione "semplice"
        """
        dist = distR = 0
        dist = distKimura(self.seq1, self.seq2)
        distR = distKimuraR(self.seq1, self.seq2, self.region)
        self.assertEqual(dist, distR)
    
    def test_05_distSimple(self):
        Cdist = distSimple(self.seq1, self.seq2)
        Pdist = PyDists.distSimple(self.seq1, self.seq2)
        self.assertAlmostEqual(Cdist, Pdist, minPos)
    
    def test_06_distSimpleR(self):
        dist = distR = 0
        dist = distSimple(self.seq1, self.seq2)
        distR = distSimpleR(self.seq1, self.seq2, self.region)
        self.assertEqual(dist, distR)
    
    # controlla che vengano sollevata una eccezione nel caso le trasversioni
    # superino in numero le transizioni
    def test_02_distKimura_exception(self):
        seq1 = "CTTCCTGTTGGGGCGTTCCC"
        seq2 = "CACGCAATAATTCGCTGCGT"
        self.assertRaises(ValueError, distKimura, seq1, seq2)
    
    def test_04_distKimuraR_exception(self):
        seq1 = "CTTCCTGTTGGGGCGTTCCC"
        seq2 = "CACGCAATAATTCGCTGCGT"
        self.assertRaises(ValueError, distKimuraR, seq1, seq2, self.region)


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCDistances)
    unittest.TextTestRunner(verbosity=2).run(suite)
