#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.seqs import Alignment
from bioinf.comp import NucComposition
from bioinf.utils import rand_alg
from bioinf.regex import NucRegEx, CompTypeError, BlankSiteError, EmptyParameterError


class TestComp(unittest.TestCase):
    def setUp(self):
        # meglio non esagerare (oltre 20 seq di lunghezza superiore a 1000)
        # che comunque gli allineamenti sono casuali, quindi non si sa mai...
        # 1000 nuc, 25 seq varia tra 1.3s e 23s, quindi...
        self.seq_length = 1000
        self.alg_len = 20
        self.alg = Alignment()
        for n, seq in enumerate(rand_alg(self.alg_len, self.seq_length, del_rate=0.02)):
            self.alg.add_seq(str(n), seq)
        comp = NucComposition()
        comp.alg = self.alg
        comp.calc_comp()
        self.comp = comp
        self.rex = NucRegEx()
    
    def test_01_regex(self):
        """
        Testa il funzionamento di NucRegEx
        """
        comp = self.comp
        rex = self.rex
        rex.analyse_alg(comp, "test")
        self.assertEqual(len(rex), 1)
    
    def test_02_regex(self):
        """
        Testa il sollevamento dell'eccezione CompTypeError
        """
        rex = self.rex
        self.assertRaises(CompTypeError, rex.analyse_alg, "", "")
        
# avevo fatto delle modifiche ad analyse_alg, che sembrano funzionare
# l'errore c'è probabilmente solo nelle vecchie regex
#    def test_03_regex(self):
#        """
#        Testa il sollevamento dell'eccezione BlankSiteError
#        """
#        rex = self.rex
#        alg = self.alg
#        #la situazione si presenta sicuramente solo quando sono due siti
#        #di seguito ad essere vuoti? non ricordo bene
#        alg.chg_site(2, '-')
#        alg.chg_site(3, '-')
#        self.comp.calc_comp()
#        self.assertRaises(BlankSiteError, rex.analyse_alg, self.comp, 'test')
    
    def test_04_regex(self):
        """
        Testa il sollevamento di EmptyParameterError
        """
        rex = self.rex
        self.assertRaises(EmptyParameterError, rex.find_in_seq, "", "")
    
    def test_05_regex(self):
        """
        Testa se la regex calcolata da' match su tutte le sequenze
        dell'allineamento
        """
        rex = self.rex
        comp = self.comp
        rex = self.rex
        alg = self.alg
        rex.analyse_alg(comp, "test")
        matches = []
        for seq in alg:
            matches.append(rex.find_in_seq("test", str(seq)))
        self.assertEqual(len(matches), len(alg))
    

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestComp)
    unittest.TextTestRunner(verbosity=2).run(suite)
