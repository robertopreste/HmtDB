#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest 
import os
from array import array
from bioinf.utils import gen_rand_seq
from bioinf.seqs import BaseSequence, Sequence, FileIO, SeqList, calc_hash, Alignment, BadSequenceType


class TestBaseSequence(unittest.TestCase):
    """
    Testa BaseSequence
    """
    def setUp(self):
        self.seq_length = 100
        self.seq = gen_rand_seq(self.seq_length)
        self.cls = BaseSequence(name="test", seq=self.seq)
    
    def test_01_create(self):
        """BaseSequence.__init__"""
        cls = BaseSequence(name="test", seq=self.seq)
        self.assertEqual(cls.seq.tostring(), self.seq)
    
    def test_02_contains(self):
        """BaseSequence.__contains__"""
        self.failUnless(self.seq[:self.seq_length / 2] in self.cls)
    
    def test_03_str(self):
        """BaseSequence.__str__"""
        self.assertEqual(str(self.cls), self.cls.seq.tostring())
    
    def test_04_lt(self):
        """BaseSequence.__lt__"""
        self.failUnless(self.cls < self.seq * 2)
    
    def test_05_le(self):
        """BaseSequence.__le__"""
        self.failUnless(self.cls <= self.seq)
    
    def test_06_gt(self):
        """BaseSequence.__gt__"""
        self.failUnless(self.cls > self.seq[:-1])
    
    def test_07_ge(self):
        """BaseSequence.__ge__"""
        self.failUnless(self.cls >= self.seq)
    
    def test_08_eq(self):
        """BaseSequence.__eq__"""
        self.failUnless(self.cls == self.seq)
    
    def test_09_ne(self):
        """BaseSequence.__ne__"""
        self.failUnless(self.cls != self.seq[:-1])
    
    def test_10_nonzero(self):
        """BaseSequence.__nonzero__"""
        self.failUnless(bool(self.cls))
    
    def test_11_getitem1(self):
        """BaseSequence.__getitem__ un sito"""
        ch1 = self.cls[self.seq_length / 2]
        ch2 = self.seq[self.seq_length / 2]
        self.assertEqual(ch1, ch2)
    
    def test_12_getitem2(self):
        """BaseSequence.__getitem__ slice complesso"""
        ch1 = self.cls[:self.seq_length / 2: 2].tostring()
        ch2 = self.seq[:self.seq_length / 2: 2]
        self.assertEqual(ch1, ch2)
    
    def test_11_getitem1(self):
        """BaseSequence.__getitem__ un sito"""
        ch1 = self.cls[self.seq_length / 2]
        ch2 = self.seq[self.seq_length / 2]
        self.assertEqual(ch1, ch2)
    
    def test_13_delitem1(self):
        """BaseSequence.__delitem__ un sito"""
        del self.cls[self.seq_length / 2]
        self.seq = list(self.seq)
        del self.seq[self.seq_length / 2]
        self.assertEqual(str(self.cls), "".join(self.seq))
    
    def test_14_delitem2(self):
        """BaseSequence.__delitem__ slice complesso"""
        del self.cls[:self.seq_length / 2: 2]
        self.seq = list(self.seq)
        del self.seq[:self.seq_length / 2: 2]
        self.assertEqual(str(self.cls), "".join(self.seq))
    
    def test_15_setitem1(self):
        """BaseSequence.__setitem__ un sito"""
        self.cls[self.seq_length / 2] = "#"
        self.seq = list(self.seq)
        self.seq[self.seq_length / 2] = "#"
        self.assertEqual(str(self.cls), "".join(self.seq))
    
    def test_15_setitem2(self):
        """BaseSequence-__setitem__ slice complesso"""
        self.cls[:self.seq_length / 2: 2] = "#" * (self.seq_length / 4)
        self.seq = list(self.seq)
        self.seq[:self.seq_length / 2: 2] = "#" * (self.seq_length / 4)
        self.assertEqual(str(self.cls), "".join(self.seq))


class TestSequence(unittest.TestCase):
    """
    Testa la classe Sequence 
    """
    def setUp(self):
        self.seq_length = 100
        self.seq = gen_rand_seq(self.seq_length)
        self.cls = Sequence(name="test", seq=self.seq, comp_type="dna")
    
    def test_01_calc_comp(self):
        """Sequence.calc_comp"""
        self.cls.calc_comp()
        self.failUnless(self.cls.comp)
    
    def test_02_check_sequence(self):
        """Sequence.check_seq"""
        self.cls.calc_comp()
        self.failUnless(self.cls.check_seq())


class TestFileIO(unittest.TestCase):
    """
    Testa il caricamento dei file
    """
    fname = os.path.join(os.path.dirname(__file__), "test_file.fasta")
    
    def setUp(self):
        self.seq_length = 100
        self.seq = gen_rand_seq(self.seq_length)
        self.cls = FileIO()
    
    def test_01_write_file(self):
        """FileIO.write_file"""
        def get_func():
            for x in range(10):
                yield "test%d" % x, self.seq
        self.cls.write_file(self.fname, "fasta", get_func)
        self.failUnless(self.cls._check_funcs["fasta"](self.fname))
    
    def test_02_load_file(self):
        """FileIO.load_file"""
        sequences = []
        
        def add_func(name, seq, **kwords):
            sequences.append(name)
        self.cls.load_file(self.fname, add_func)
        self.assertEqual(len(sequences), 10)
    
    def __del__(self):
        if os.path.isfile(self.fname):
            os.remove(self.fname)


class TestSeqList(unittest.TestCase):
    """
    Testa la classe SeqList
    """
    def setUp(self):
        self.cls = SeqList()

    def test_01_add_seq(self):
        """SeqList.add_seq"""
        self.cls.add_seq(name="test", seq=gen_rand_seq(20), test="test")
        self.assertEqual(len(self.cls), 1)
    
    def test_02_remove_seqs(self):
        """SeqList.remove_seqs"""
        self.cls.add_seq(name="test", seq=gen_rand_seq(20), test="test")
        self.cls.remove_seqs()
        self.assertEqual(len(self.cls), 0)
    
    def setup_getters(self):
        self.seq1 = gen_rand_seq(20)
        self.seq2 = gen_rand_seq(40)
        self.cls.add_seq(name="test", seq=self.seq1, test="test")
        self.cls.add_seq(name="test1", seq=self.seq2, test="test1")
    
    def test_03_get_seq_by_index(self):
        """SeqList.get_seq_by_index"""
        self.setup_getters()
        seqx = self.cls.get_seq_by_index(1)
        self.assertEqual(self.seq2, seqx)
    
    def test_04_get_seq_by_name(self):
        """SeqList.get_seq_by_name"""
        self.setup_getters()
        seqx = self.cls["test1"]
        self.assertEqual(self.seq2, seqx)
    
    def test_05_get_seq_by_hash(self):
        """SeqList.get_seq_by_hash"""
        self.setup_getters()
        seqx = self.cls[calc_hash(self.seq2)]
        self.assertEqual(self.seq2, seqx)
    
    def test_06_get_index_by_name(self):
        """SeqList.get_index_by_name"""
        self.setup_getters()
        idx = self.cls.get_index_by_name("test1")
        self.assertEqual(idx, 1)
    
    def test_07_get_index_by_hash(self):
        """SeqList.get_index_by_hash"""
        self.setup_getters()
        idx = self.cls.get_index_by_hash(calc_hash(self.seq2))
        self.assertEqual(idx, 1)
    
    def test_08_get_pos(self):
        """SeqList.get_pos"""
        self.setup_getters()
        seqs = list(self.cls.get_pos())
        seqx = [(0, "test"), (1, "test1")]
        self.assertEqual(seqs, seqx)
    
    def test_09_get_items(self):
        """SeqList.get_items"""
        self.setup_getters()
        seqs = list(self.cls.get_items())
        seqx = [("test", self.seq1), ("test1", self.seq2)]
        self.assertEqual(seqs, seqx)
    
    def test_10_get_duplicates(self):
        """SeqList.get_duplicates"""
        self.setup_getters()
        self.cls.add_seq("test2", self.seq1)
        seqx = [x for x in self.cls.get_duplicates()]
        self.assertEqual(len(seqx), 2)
    
    def test_11_get_hash(self):
        """SeqList.get_hash"""
        self.setup_getters()
        hsh = array("c")
        for x in self.cls:
            hsh += x.hash
        hsh = calc_hash(hsh)
        self.assertEqual(hsh, self.cls.get_hash())
    
    def test_12_contains(self):
        """SeqList.__contains__"""
        self.setup_getters()
        seq = BaseSequence("test", self.seq1)
        self.failUnless(seq in self.cls)
    
    def test_12_lt(self):
        """SeqList.__lt__"""
        self.setup_getters()
        cls2 = SeqList()
        for x in range(3):
            cls2.add_seq("test", self.seq1)
        self.failUnless(self.cls < cls2)
    
    def test_13_le(self):
        """SeqList.__le__"""
        self.setup_getters()
        cls2 = SeqList()
        for x in range(2):
            cls2.add_seq("test", self.seq1)
        self.failUnless(self.cls <= cls2)
    
    def test_14_gt(self):
        """SeqList.__gt__"""
        self.setup_getters()
        cls2 = SeqList()
        for x in range(1):
            cls2.add_seq("test", self.seq1)
        self.failUnless(self.cls > cls2)
    
    def test_15_ge(self):
        """SeqList.__ge__"""
        self.setup_getters()
        cls2 = SeqList()
        for x in range(2):
            cls2.add_seq("test", self.seq1)
        self.failUnless(self.cls >= cls2)
    
    def test_16_eq(self):
        """SeqList.__eq__"""
        self.setup_getters()
        cls2 = SeqList()
        cls2.add_seq("test", self.seq1)
        cls2.add_seq("test1", self.seq2)
        self.failUnless(self.cls == cls2)
    
    def test_17_ne(self):
        """SeqList.__ne__"""
        self.setup_getters()
        cls2 = SeqList()
        for x in range(2):
            cls2.add_seq("test", self.seq1)
        self.failUnless(self.cls != cls2)
    
    def test_18_nonzero(self):
        """SeqList.__nonzero__"""
        self.setup_getters()
        self.failUnless(self.cls)
    
    def test_19_getitem(self):
        """SeqList.__getitem__ slice"""
        self.setup_getters()
        step = 2
        for x in xrange(2, 10):
            self.cls.add_seq("test%d" % x, self.seq1)
        seql = [self.cls[x] for x in xrange(0, len(self.cls), step)]
        seqx = self.cls[0:len(self.cls):step]
        self.assertEqual(seql, seqx)
    
    def test_20_delitem1(self):
        """SeqList.__delitem__ int"""
        self.setup_getters()
        del self.cls[1]
        self.assertEqual(len(self.cls), 1)
    
    def test_20_delitem2(self):
        """SeqList.__delitem__ slice"""
        self.setup_getters()
        step = 2
        for x in xrange(2, 10):
            self.cls.add_seq("test%d" % x, self.seq1)
        cls_len = len(self.cls)
        del self.cls[:cls_len:step]
        self.assertEqual(len(self.cls), len(range(0, cls_len, step)))
    
    def test_21_setitem1(self):
        """SeqList.__setitem__ int"""
        self.setup_getters()
        self.cls[0] = self.cls._seq_cls("test0", self.seq1)
        self.assertEqual(self.cls[0].name, "test0")
    
    def test_21_setitem2(self):
        """SeqList.__setitem__ slice"""
        self.setup_getters()
        step = 2
        list_len = 10
        for x in xrange(2, list_len):
            self.cls.add_seq("test%d" % x, self.seq1)
        self.cls[0:list_len:step] = [BaseSequence("test0", self.seq1) for x in xrange(0, list_len, step)]
        names = [seq for seq in self.cls if seq.name == "test0"]
        self.assertEqual(len(names), len(range(0, list_len, step)))
    
    def test_21_setitem3(self):
        """SeqList.__setitem__ int - raise BadSequenceType"""
        self.setup_getters()
        self.assertRaises(BadSequenceType, self.cls.__setitem__, 1, 0)
    
    def test_21_setitem4(self):
        """SeqList.__setitem__ slice - raise BadSequenceType"""
        self.setup_getters()
        self.assertRaises(BadSequenceType, self.cls.__setitem__, slice(0, 1), [0, 1])


class TestAlignment(unittest.TestCase):
    """
    Testa la classe Alignment
    """
    def setUp(self):
        # ora non è più attivata di default la tracciatura della lunghezza
        # dell'allineamento
        self.alg = Alignment(track=True)
        self.seq_len = 20
        self.seq = gen_rand_seq(self.seq_len)
        self.alg.add_seq("test", self.seq)
    
    def test_01_add_seq1(self):
        """Alignment.add_seq seq_len+1"""
        self.alg.add_seq("test", self.seq + "A")
        self.assertEqual(self.alg[0].seq[-1], "-")
    
    def test_01_add_seq2(self):
        """Alignment.add_seq seq_len-1"""
        self.alg.add_seq("test", self.seq[:-1])
        self.assertEqual(self.alg[1].seq[-1], "-")
    
    def test_02_seq_len1(self):
        """Alignment._set_seq_len seq_len+1"""
        self.alg.add_seq("test", self.seq)
        self.alg.seq_len = len(self.seq) + 1
        self.failUnless(self.alg[0].seq[-1] == self.alg[0].seq[-1] == "-")
    
    def test_02_seq_len2(self):
        """Alignment._set_seq_len seq_len-1"""
        self.alg.add_seq("test", self.seq)
        self.alg.seq_len = len(self.seq) - 1
        self.failUnless(len(self.alg[0]) == len(self.alg[0]) == len(self.seq) - 1)
    
    def test_03_remove_seqs(self):
        """Alignment.remove_seqs"""
        self.alg.remove_seqs()
        self.failUnless(len(self.alg) == self.alg.seq_len == 0)
    
    def test_04_del_site1(self):
        """Alignment.del_site"""
        self.alg.add_seq("test", self.seq)
        self.alg.del_site(self.seq_len / 2)
        self.failUnless(self.alg[0][self.seq_len / 2] == self.alg[1][self.seq_len / 2] == self.seq[self.seq_len / 2 + 1])
    
    def test_04_del_site2(self):
        """Alignment.del_site slice"""
        self.alg.add_seq("test", self.seq)
        self.alg.del_site(slice(0, self.seq_len, 2))
        count = 0
        checks = []
        for x in range(0, self.seq_len, 2):
            checks.append(self.alg[0][x - count] == self.alg[1][x - count] == self.seq[x + 1])
            count += 1
        self.failUnless(all(checks))
    
    def test_05_chg_site1(self):
        """Alignment.chg_site"""
        self.alg.add_seq("test", self.seq)
        self.alg.chg_site(self.seq_len / 2, "-")
        self.failUnless(self.alg[0][self.seq_len / 2] == self.alg[1][self.seq_len / 2] == "-")
    
    def test_05_chg_site2(self):
        """Alignment.chg_site slice"""
        self.alg.add_seq("test", self.seq)
        self.alg.chg_site(slice(0, self.seq_len, 2), "-" * len(range(0, self.seq_len, 2)))
        checks = []
        for x in range(0, self.seq_len, 2):
            checks.append(self.alg[0][x] == self.alg[1][x] == "-")
        self.failUnless(all(checks))
    
    def test_06_add_site1(self):
        """Alignment.add_site int"""
        self.alg.add_seq("test", self.seq)
        self.alg.add_site(self.seq_len / 2, "-")
        self.failUnless(self.alg[0][self.seq_len / 2 + 1] == self.alg[1][self.seq_len / 2 + 1] == "-" and self.alg.seq_len == self.seq_len + 1)
    
    def test_06_add_site2(self):
        """Alignment.add_site slice"""
        self.alg.add_seq("test", self.seq)
        self.alg.add_site(slice(0, self.seq_len, 2), "-")
        count = 0
        checks = []
        for x in range(0, self.seq_len, 2):
            checks.append(self.alg[0][x + 1 + count] == self.alg[1][x + 1 + count] == "-")
            count += 1
        self.failUnless(all(checks))


if __name__ == '__main__':
    Tests = [cls for name, cls in globals().items() if name.startswith("Test")]
    loader = unittest.TestLoader()
    cases = [loader.loadTestsFromTestCase(x) for x in Tests]
    suite = unittest.TestSuite()
    suite.addTests(cases)
    unittest.TextTestRunner(verbosity=2).run(suite)
