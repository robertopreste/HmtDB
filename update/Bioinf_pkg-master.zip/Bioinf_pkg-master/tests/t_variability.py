#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.c_distances import distKimura, distSimple
from bioinf.sitevar import Variability
from bioinf.c_variability import Variability as CVariability


class TestVariability(unittest.TestCase):
    def setUp(self):
        base = ["ACYGV" * 2, "TRATG" * 3, "CNTGAC" * 2, "BAWCK" * 4, "RYNT" * 3]
        self.seq1 = "".join(base)
        self.seq2 = "".join(reversed(base))
        self.dist = distKimura(self.seq1, self.seq2)
        self.params = [(0.0, 1.0, 2.0, 0.0),  # ambiguita' senza peso
                       (1.0, 2.0, 3.0, 0.5)]  # aumentati pesi
                      
    def test_01_Variability_default(self):
        Pvar = Variability()
        Pvar.reset_values(len(self.seq1))
        Pvar.varSequence(self.seq1, self.seq2, 0, len(self.seq1), self.dist)
        Cvar = CVariability()
        Cvar.reset_values(len(self.seq1))
        Cvar.varSequence(self.seq1, self.seq2, 0, len(self.seq1), self.dist)
        self.assertEqual(Pvar.rates, Cvar.rates)
    
    def test_02_Variability_no_Ambiguity(self):
        Pvar = Variability()
        Pvar.reset_values(len(self.seq1), *self.params[0])
        Pvar.varSequence(self.seq1, self.seq2, 0, len(self.seq1), self.dist)
        Cvar = CVariability()
        Cvar.reset_values(len(self.seq1), *self.params[0])
        Cvar.varSequence(self.seq1, self.seq2, 0, len(self.seq1), self.dist)
        self.assertEqual(Pvar.rates, Cvar.rates)
    
    def test_03_Variability_more_weight(self):
        Pvar = Variability()
        Pvar.reset_values(len(self.seq1), *self.params[1])
        Pvar.varSequence(self.seq1, self.seq2, 0, len(self.seq1), self.dist)
        Cvar = CVariability()
        Cvar.reset_values(len(self.seq1), *self.params[1])
        Cvar.varSequence(self.seq1, self.seq2, 0, len(self.seq1), self.dist)
        self.assertEqual(Pvar.rates, Cvar.rates)


if __name__ == '__main__':
    Tests = [cls for name, cls in globals().items() if name.startswith("Test")]
    loader = unittest.TestLoader()
    cases = [loader.loadTestsFromTestCase(x) for x in Tests]
    suite = unittest.TestSuite()
    suite.addTests(cases)
    unittest.TextTestRunner(verbosity=2).run(suite)
