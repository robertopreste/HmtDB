#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

from datetime import datetime
from bioinf.seqs import Alignment
from bioinf.c_distances import distKimuraR as CdistKimuraR
from bioinf.c_distances import distSimpleR as CdistSimpleR
from bioinf.distances import distKimuraR, distSimpleR
from bioinf.sitevar import SiteVar, Variability
from bioinf.c_variability import Variability as CVariability
from bioinf.utils import rand_alg
import logging 
import os

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s %(name)-12s %(levelname)-8s %(message)s",
                    filename=os.path.splitext(os.path.join(os.getcwd(), os.path.basename(__file__)))[0]+".log",
                    filemode="w")
console = logging.StreamHandler()
formatter = logging.Formatter("[%(levelname)-8s] %(message)s")
console.setFormatter(formatter)
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)


def setup(seq_len, alg_len):
    alg = Alignment()
    for n, seq in enumerate(rand_alg(alg_len, seq_len, del_rate=0.05)):
        alg.add_seq("test%d" % n, seq)
    
    return alg


def benchmark(alg, dist, var):
    sv = SiteVar()
    sv.alg = alg
    sv.set_dist_type(dist)
    sv.set_var_type(var)
    sv.set_weights()
    str_block = datetime.now()
    sv.run_analysis()
    end_block = datetime.now()
    
    return end_block - str_block


steps = ((distKimuraR, Variability, "kimura python"),
         (distSimpleR, Variability, "simple python"),
         (CdistKimuraR, CVariability, "kimura C"),
         (CdistSimpleR, CVariability, "simple C"))

params = ((6000, 35),
          (6000, 70),
          (6000, 105),
          (6000, 140),
          (6000, 175),
          (6000, 210),
          (6000, 245))

logging.info("Starting SiteVar Benchmarks")
logging.info("=" * 80)

tot_start = datetime.now()

for seq_len, alg_len in params:
    start_block = datetime.now()
    logging.info("Using Alignment length: %d and sequence length %d" % (alg_len, seq_len))
    alg = setup(seq_len, alg_len)
    for dist, var, desc in steps:
        time = benchmark(alg, dist, var)
        logging.info("%s done in %s" % (desc, str(time)))
    end_block = datetime.now()
    logging.info("Test Time: %s" % (end_block - start_block))
    logging.info("-" * 80)

tot_end = datetime.now()

logging.info("~" * 80)
logging.info("Total Time: %s" % (tot_end - tot_start))
logging.info("=" * 80)
