#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.seqs import Alignment
from bioinf.c_distances import distKimuraR, distSimpleR
from bioinf.sitevar import gen_relative_pos, SiteVar
from bioinf.c_variability import Variability as CVariability
from bioinf.utils import rand_alg


class TestGenRelativePos(unittest.TestCase):
    def setUp(self):
        self.seq = "A-AC---AAA-TT-"
        self.result = {1: "1", 2: "1.1", 3: "2", 4: "3", 5: "3.1", 6: "3.2", 7: "3.3",
                       8: "4", 9: "5", 10: "6", 11: "6.1", 12: "7", 13: "8", 14: "8.1"}
    
    def test_01_gen_rel(self):
        """gen_relative_pos"""
        res_x = gen_relative_pos(self.seq.replace("-", ""), self.seq)
        self.assertEqual(self.result, res_x)


class TestSiteVar(unittest.TestCase):
    def setUp(self):
        self.seq_length = 150
        self.alg_len = 50
        self.alg = Alignment()
        for n, seq in enumerate(rand_alg(self.alg_len, self.seq_length, del_rate=0.05)):
            self.alg.add_seq("test%d" % n, seq)
        self.sitevar = SiteVar()
        self.sitevar.alg = self.alg
        self.sitevar.set_dist_type()
        self.sitevar.set_var_type()
        self.sitevar.set_weights()
    
    def test_01_check_seq(self):
        """SiteVar.check_seq"""
        for x in range(10):
            self.alg.add_seq("partial%d" % x, "-" * 25 + "A" * 100 + "-" * 25)
        self.sitevar.gapnumber = 25
        self.sitevar.check_seqs()
        self.assertEqual(len(self.sitevar.part_seqs), 10)
    
    def test_02_set_weigths(self):
        """SiteVar.set_weigths"""
        self.sitevar.set_weights(10, 20, 30, 40)
        self.failUnless(self.sitevar._gap == 10 and self.sitevar._transition == 20 and self.sitevar._transversion == 30 and self.sitevar._ambiguity == 40)
    
    def test_sitevar1(self):
        """SiteVar minima configurazione, Python"""
        self.sitevar.run_analysis()
        self.failUnless(self.sitevar.rates)
    
    def test_sitevar2(self):
        """SiteVar kimura distance, C Variability"""
        self.sitevar.set_dist_type(distKimuraR)
        self.sitevar.set_var_type(CVariability)
        self.sitevar.run_analysis()
        self.failUnless(self.sitevar.rates)
    
    def test_sitevar3(self):
        """SiteVar simple distance, C Variability"""
        self.sitevar.set_dist_type(distSimpleR)
        self.sitevar.set_var_type(CVariability)
        self.sitevar.run_analysis()
        self.failUnless(self.sitevar.rates)
    
    def test_sitevar4(self):
        """SiteVar wgaps=False"""
        self.sitevar.run_analysis()
        self.wgaps = False
        self.failUnless(self.sitevar.rates)
    
    def test_sitevar5(self):
        """SiteVar exclude=1"""
        self.sitevar.exclude = 1
        self.sitevar.run_analysis()
        self.failUnless(self.sitevar.exclude not in self.sitevar.comp_seqs)
    
    def test_sitevar6(self):
        """SiteVar normalize=False"""
        self.sitevar.normalize = False
        self.sitevar.run_analysis()
        self.failUnless(self.sitevar.rates[0] > 1)


if __name__ == '__main__':
    Tests = [cls for name, cls in globals().items() if name.startswith("Test")]
    loader = unittest.TestLoader()
    cases = [loader.loadTestsFromTestCase(x) for x in Tests]
    suite = unittest.TestSuite()
    suite.addTests(cases)
    unittest.TextTestRunner(verbosity=2).run(suite)
