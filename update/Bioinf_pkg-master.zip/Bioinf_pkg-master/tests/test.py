#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
import t_utils
import t_events
import t_distances
import t_c_distances
import t_variability
import t_seqs
import t_comp
import t_regex
import t_sitevar
import t_tabtor

tests = [t_utils,
         t_events,
         t_distances,
         t_c_distances,
         t_variability,
         t_seqs,
         t_comp,
         t_regex,
         t_sitevar,
         t_tabtor]


if __name__ == '__main__':
    loader = unittest.TestLoader()
    cases = [loader.loadTestsFromModule(module) for module in tests]
    suite = unittest.TestSuite()
    suite.addTests(cases)
    unittest.TextTestRunner(verbosity=2).run(suite)
