#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.distances import distKimura, distKimuraR, distSimple, distSimpleR

"""
Utilizzato nel confronto tra la distanza calcolata da me sulle sequenze e tra
quelle calcolate dalle funzioni python.
Serve solo a rendersi conto che i risultati siano ragionevoli dato che il
risultato dipende dal compilatore e dalle ottimizzazioni utilizzate nel build
di Python, che normalmente sono standard, ma potrebbero essere state cambiate
12 posizioni decimali sono molte, per me 8-9 sono perfette
"""
minPos = 12


class TestDistances(unittest.TestCase):
    def setUp(self):
        self.seq1 = "ATACAGGACTTATAACTAGT"
        self.seq2 = "TTCAGGGATGAGTGCGCACT"
        self.region = ((0, len(self.seq1) // 2), (len(self.seq1) // 2, len(self.seq1)))
    
    def test_01_distKimura(self):
        dist = distKimura(self.seq1, self.seq2)
        self.assertAlmostEqual(1.5536520246055481, dist, minPos)
    
    def test_03_distKimuraR(self):
        dist = distR = 0
        dist = distKimura(self.seq1, self.seq2)
        distR = distKimuraR(self.seq1, self.seq2, self.region)
        self.assertEqual(dist, distR)
    
    def test_05_distSimple(self):
        dist = distSimple(self.seq1, self.seq2)
        self.assertAlmostEqual(0.65000000000000002, dist, minPos)
    
    def test_06_distSimpleR(self):
        dist = distR = 0
        dist = distSimple(self.seq1, self.seq2)
        distR = distSimpleR(self.seq1, self.seq2, self.region)
        self.assertEqual(dist, distR)
    
    def test_02_distKimura_exception(self):
        seq1 = "CTTCCTGTTGGGGCGTTCCC"
        seq2 = "CACGCAATAATTCGCTGCGT"
        self.assertRaises(ValueError, distKimura, seq1, seq2)
    
    def test_04_distKimuraR_exception(self):
        seq1 = "CTTCCTGTTGGGGCGTTCCC"
        seq2 = "CACGCAATAATTCGCTGCGT"
        self.assertRaises(ValueError, distKimuraR, seq1, seq2, self.region)


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestDistances)
    unittest.TextTestRunner(verbosity=2).run(suite)
