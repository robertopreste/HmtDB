#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.utils import rand_seq_del, rand_seq_nuc, gen_rand_seq, pyr, pur, rand_alg, snp_to_seq
from bioinf.events import isTransition, isTransversion
from random import randint, choice


class TestUtils(unittest.TestCase):
    def setUp(self):
        self.seq_length = 1000000
        self.alg_len = 10

    def test_01_gen_rand_seq1(self):
        """
        Testa che la quantita' di nucleotidi sia all'incirca quella specificata
        per lunghezze >= 1.000.000 di basi e che i valori di default siano
        giusti
        """
        seq = gen_rand_seq(self.seq_length)
        
        pur_perc = sum(seq.count(nuc) for nuc in pur) / float(self.seq_length)
        pyr_perc = sum(seq.count(nuc) for nuc in pyr) / float(self.seq_length)
        
        self.assertAlmostEquals(pur_perc, pyr_perc, 1, "Pur %2f, Pyr: %2f" % (pur_perc, pyr_perc))
    
    def test_02_gen_rand_seq2(self):
        """
        Testa che si possano cambiare i valori delle probabilita' dei nucleotidi
        impostando le purine all'80%
        """
        seq = gen_rand_seq(self.seq_length, A=0.40, G=0.40, C=0.10, T=0.10)
        
        pur_perc = sum(seq.count(nuc) for nuc in pur) / float(self.seq_length)
        
        self.assertAlmostEquals(pur_perc, 0.80, 1, "Atteso %2f, risultato: %2f" % (0.80, pur_perc))
    
    def test_03_rand_seq_nuc(self):
        """
        Testa se il numero di sostituzioni sia uguale a quello atteso
        """
        rate = 0.25
        seq1 = gen_rand_seq(self.seq_length)
        seq2 = rand_seq_nuc(seq1, sost_rate=rate)
        rt = sum(1 for nuc1, nuc2 in zip(seq1, seq2) if nuc1 != nuc2) / float(self.seq_length)
        self.assertAlmostEqual(rate, rt, 1, "Atteso %2f, risultato: %2f" % (rate, rt))
    
    def test_04_rand_seq_nuc2(self):
        """
        Testa se il numero di transizioni sia uguale a quello atteso
        """
        rate = 0.65
        seq1 = gen_rand_seq(self.seq_length)
        seq2 = rand_seq_nuc(seq1, sost_rate=0.30, trs_rate=rate)
        # sostituzioni totali
        tot = sum(1 for nuc1, nuc2 in zip(seq1, seq2) if nuc1 != nuc2)
        # solo transizioni
        trs = sum(1 for nuc1, nuc2 in zip(seq1, seq2) if isTransition(nuc1, nuc2) and nuc1 != nuc2)
        rt = trs / float(tot)
        self.assertAlmostEqual(rate, rt, 1, "Atteso %2f, risultato: %2f" % (rate, rt))
    
    def test_05_rand_seq_nuc3(self):
        """
        Testa se il numero di trasversioni sia uguale a quello atteso
        """
        rate = 0.35
        seq1 = gen_rand_seq(self.seq_length)
        seq2 = rand_seq_nuc(seq1, sost_rate=0.30, trs_rate=rate)
        # sostituzioni totali
        tot = sum(1 for nuc1, nuc2 in zip(seq1, seq2) if nuc1 != nuc2)
        # solo trasversioni
        tsv = sum(1 for nuc1, nuc2 in zip(seq1, seq2) if isTransversion(nuc1, nuc2))
        rt = tsv / float(tot)
        self.assertAlmostEqual(1-rate, rt, 1, "Atteso %2f, risultato: %2f" % (1 - rate, rt))
    
    def test_06_rand_seq_del1(self):
        """
        Testa se il numero di delezioni sia uguale a quello atteso
        """
        rate = 0.20
        seq1 = gen_rand_seq(self.seq_length)
        seq2 = rand_seq_del(seq1, del_rate=rate, del_char=None)
        rt = (self.seq_length - len(seq2)) / float(self.seq_length)
        self.assertAlmostEqual(rate, rt, 1, "Atteso %2f, risultato: %2f" % (rate, rt))
    
    def test_07_rand_seq_del2(self):
        """
        Testa se il numero di gap sia uguale a quello atteso
        """
        rate = 0.20
        seq1 = gen_rand_seq(self.seq_length)
        seq2 = rand_seq_del(seq1, del_rate=rate, del_char="-")
        rt = seq2.count("-") / float(self.seq_length)
        self.assertAlmostEqual(rate, rt, 1, "Atteso %2f, risultato: %2f" % (rate, rt))
    
    def test_08_rand_alg(self):
        """
        Testa se il numero di sequenze generate e' giusto
        """
        alg = [x for x in rand_alg(self.alg_len, 1000)]
        self.assertEqual(len(alg), self.alg_len, "Atteso: %d, risultato: %d" % (len(alg), self.alg_len))
    
    def test_09_rand_alg(self):
        """
        Testa se la lunghezza delle sequenze generate e' giusto
        """
        seq_len = 1000
        alg = all([True for x in rand_alg(self.alg_len, seq_len) if len(x) == seq_len])
        self.failUnless(alg, "Una delle lunghezze e' diversa dall'atteso")
    
    def test_10_rand_alg(self):
        """
        Testa se la ci sono errori nell'uso di del_rate, dipende dal precedente
        """
        seq_len = 1000
        alg = all([True for x in rand_alg(self.alg_len, seq_len, del_rate=0.10) if len(x) == seq_len])
        self.failUnless(alg)
    
    def test_11_snp_to_seq1(self):
        """
        Testa che le transizioni funzionino
        """
        seq1 = gen_rand_seq(100)
        changes = [(randint(1, 100), 0, None) for x in range(20)]
        seq2 = snp_to_seq(seq1, changes)
        results = [True for x, y in zip(seq1, seq2) if x != y and isTransition(x, y)]
        self.failUnless(all(results))
    
    def test_11_snp_to_seq2(self):
        """
        Testa che le trasversioni funzionino
        """
        seq1 = gen_rand_seq(100)
        pur = ("A", "G")
        pyr = ("T", "C")
        changes = []
        for x in range(20):
            pos = randint(1, 100)
            change = choice(pur) if seq1[pos] in pyr else choice(pyr)
            changes.append((pos, 1, change))
        seq2 = snp_to_seq(seq1, changes)
        results = [True for x, y in zip(seq1, seq2) if isTransversion(x, y)]
        self.failUnless(all(results))
    
    def test_11_snp_to_seq3(self):
        """
        Testa che le delezioni funzionino
        """
        seq1 = gen_rand_seq(100)
        changes = [(20, 2, 30), (80, 2, 81), (40, 2, 43), (10, 2, 14)]
        seq2 = snp_to_seq(seq1, changes)
        results = []
        changes.sort()
        self.failUnless(len(seq1) - len(seq2), 18)
    
    def test_11_snp_to_seq4(self):
        """
        Testa che le inserzioni funzionino
        """
        seq1 = gen_rand_seq(100)
        changes = [(20, 3, "ATGACA"), (80, 3, "g"), (40, 3, "ccac"), (10, 4, "A")]
        seq2 = snp_to_seq(seq1, changes)
        results = []
        changes.sort()
        self.failUnless(len(seq2) - len(seq1), 12)


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestUtils)
    unittest.TextTestRunner(verbosity=2).run(suite)
