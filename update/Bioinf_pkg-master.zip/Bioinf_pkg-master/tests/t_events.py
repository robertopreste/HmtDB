#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.events import isTransition, isTransversion, isAmbiguity


class TestEvents(unittest.TestCase):
    def setUp(self):
        base = ["ACYG" * 2, "TRATG" * 3, "CNTGAC" * 2, "BNWBK" * 4, "RYNT" * 3]
        self.seq1 = "".join(base)
        self.seq2 = "".join(reversed(base))
        print ""
        print self.seq1
        print self.seq2
    
    def test_isTransition(self):
        trs1 = trs2 = 0
        for x, y in zip(self.seq1, self.seq2):
            if isTransition(x, y) and x != y:
                trs1 += 1
        for x, y in zip(self.seq2, self.seq1):
            if isTransition(x, y) and x != y:
                trs2 += 1
        print "transitions found:", trs1, ""
        self.assertEqual(trs1, trs2)
    
    def test_isTransversion(self):
        trs1 = trs2 = 0
        for x,  in zip(self.seq1, self.seq2):
            if isTransversion(x, y):
                trs1 += 1
        for x, y in zip(self.seq2, self.seq1):
            if isTransversion(x, y):
                trs2 += 1
        print "transversions found:", trs1, ""
        self.assertEqual(trs1, trs2)
    
    def test_isAmbiguity(self):
        amb1 = amb2 = 0
        for x, y in zip(self.seq1, self.seq2):
            if isAmbiguity(x, y):
                amb1 += 1
        for x, y in zip(self.seq2, self.seq1):
            if isAmbiguity(x, y):
                amb2 += 1
        print "ambiguities found:", amb1, ""
        self.assertEqual(amb1, amb2)


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestEvents)
    unittest.TextTestRunner(verbosity=2).run(suite)
