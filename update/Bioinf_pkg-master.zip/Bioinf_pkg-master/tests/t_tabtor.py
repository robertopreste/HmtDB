#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest 
import os
from bioinf.tab_tor import TabTorCln
from bioinf.seqs import Alignment
from bioinf.utils import rand_alg
from bioinf.sitevar import gen_relative_pos, SiteVar


class TestTabTor(unittest.TestCase):
    """Testa la classe TabTorCln"""
    fname = os.path.join(os.path.dirname(__file__), "test_file")
    
    def setUp(self):
        self.seq_length = 150
        self.alg_len = 50
        self.alg = Alignment()
        for n, seq in enumerate(rand_alg(self.alg_len, self.seq_length, del_rate=0.05)):
            self.alg.add_seq("test%d" % n, seq)
        self.tabtor = TabTorCln()
        self.tabtor.alg = self.alg
    
    def test_01_cln_create1(self):
        """TabTorCln.cln_create clean=True"""
        for x in range(1, 11):
            self.alg.add_seq("dupl%d" % x, self.alg[x].seq.tostring())
        self.tabtor.cln_create()
        self.failUnless(len(self.tabtor.freqs) == self.alg_len - 1 and len([x for x in self.tabtor.freqs.itervalues() if x > 1]) == 10)
    
    def test_01_cln_create2(self):
        """TabTorCln.cln_create clean=False"""
        for x in range(1, 11):
            self.alg.add_seq("dupl%d" % x, self.alg[x].seq.tostring())
        self.tabtor.cln_create(clean=False)
        self.failUnless(len(self.tabtor.freqs) == self.alg_len + 9 and len([x for x in self.tabtor.freqs.itervalues() if x > 1]) == 0)
    
    def test_02_tab_create(self):
        """TabTorCln.tab_create"""
        self.tabtor.tab_create()
        self.failUnless(getattr(self.tabtor, "tab", None) and getattr(self.tabtor, "rseq", None) and getattr(self.tabtor, "pos", None))
    
    def test_04_tab_write1(self):
        """TabTorCln.tab_write defaults"""
        self.tabtor.tab_write(self.fname)
        self.failUnless(os.path.isfile(self.fname))
    
    def test_04_tab_write1(self):
        """TabTorCln.tab_write with tab_reduce"""
        sv = SiteVar()
        sv.alg = self.alg
        sv.set_dist_type()
        sv.set_var_type()
        sv.set_weights()
        sv.run_analysis()
        self.tabtor.in_rates = sv.rates
        self.tabtor.tab_write(self.fname, n_sites=10)
        self.failUnless(os.path.isfile(self.fname))
    
    def test_04_tab_write2(self):
        """TabTorCln.tab_write in_rel_pos"""
        rel_pos = gen_relative_pos(self.alg[2].seq.tostring().replace("-", ""), self.alg[2].seq)
        self.tabtor.tab_write(self.fname, in_rel_pos=rel_pos)
        self.failUnless(os.path.isfile(self.fname))
    
    def test_03_tab_reduce1(self):
        """TabTorCln.tab_reduce defaults"""
        sv = SiteVar()
        sv.alg = self.alg
        sv.set_dist_type()
        sv.set_var_type()
        sv.set_weights()
        sv.run_analysis()
        self.tabtor.in_rates = sv.rates
        self.tabtor.tab_create()
        tab, pos, rseq = self.tabtor.tab_reduce()
        self.assertNotEquals([tab, pos, rseq], [self.tabtor.tab, self.tabtor.pos, self.tabtor.rseq])
    
    def test_03_tab_reduce2(self):
        """TabTorCln.tab_reduce sortmax=False"""
        sv = SiteVar()
        sv.alg = self.alg
        sv.set_dist_type()
        sv.set_var_type()
        sv.set_weights()
        sv.run_analysis()
        self.tabtor.in_rates = sv.rates
        self.tabtor.tab_create()
        tab1, pos1, rseq1 = self.tabtor.tab_reduce(n_sites=20, sortmax=True)
        tab2, pos2, rseq2 = self.tabtor.tab_reduce(n_sites=20, sortmax=False)
        self.assertNotEquals([tab2, pos2, rseq2], [tab1, pos1, rseq1])
    
    def test_03_tab_reduce3(self):
        """TabTorCln.tab_reduce sortpos=False"""
        sv = SiteVar()
        sv.alg = self.alg
        sv.set_dist_type()
        sv.set_var_type()
        sv.set_weights()
        sv.run_analysis()
        self.tabtor.in_rates = sv.rates
        self.tabtor.tab_create()
        tab1, pos1, rseq1 = self.tabtor.tab_reduce(n_sites=20, sortpos=True)
        tab2, pos2, rseq2 = self.tabtor.tab_reduce(n_sites=20, sortpos=False)
        self.assertNotEquals([tab2, pos2, rseq2], [tab1, pos1, rseq1])
    
    def test_05_tor_create1(self):
        """TabTorCln.tor_create defaults"""
        self.tabtor.tor_create(self.fname)
        self.failUnless(os.path.isfile(self.fname))
    
    def test_05_tor_create2(self):
        """TabTorCln.tor_create in_rel_pos"""
        rel_pos = gen_relative_pos(self.alg[2].seq.tostring().replace("-", ""), self.alg[2].seq)
        self.tabtor.tor_create(self.fname, in_rel_pos=rel_pos)
        self.failUnless(os.path.isfile(self.fname))
    
    def __del__(self):
        if os.path.isfile(self.fname):
            os.remove(self.fname)


if __name__ == '__main__':
    Tests = [cls for name, cls in globals().items() if name.startswith("Test")]
    loader = unittest.TestLoader()
    cases = [loader.loadTestsFromTestCase(x) for x in Tests]
    suite = unittest.TestSuite()
    suite.addTests(cases)
    unittest.TextTestRunner(verbosity=2).run(suite)
