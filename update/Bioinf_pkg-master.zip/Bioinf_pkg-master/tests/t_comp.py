#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste

import unittest
from bioinf.seqs import Alignment
from bioinf.comp import NucComposition
from bioinf.utils import rand_alg


class TestComp(unittest.TestCase):
    def setUp(self):
        self.seq_length = 16000
        self.alg_len = 100
        self.chunck = 50
        self.alg = Alignment()
        for n, seq in enumerate(rand_alg(self.alg_len, self.seq_length, del_rate=0.1)):
            self.alg.add_seq(str(n), seq)
        comp = NucComposition()
        comp.alg = self.alg 
        self.comp = comp

    def test_01_comp(self):
        """
        Testa il funzionamento di NucComposition
        """
        comp = self.comp
        comp.alg = self.alg
        comp.calc_comp()
        self.failUnless(len(comp.comp) == self.seq_length)

    def test_02_comp(self):
        """
        Testa che la composizione di 2 regioni che comprandano l'intero
        allineamento sia identica alla composizione calcolata sull'intero
        allineamento
        """
        comp = self.comp
        comp.calc_comp()
        comp_all = comp.comp
        comp.set_ranges((0, self.seq_length / 2), (self.seq_length / 2, self.seq_length))
        comp.calc_comp()
        comp_region = comp.comp
        self.failUnless(comp_region == comp_all)

    def test_03_comp(self):
        """
        Testa che la composizione calcolata sulle prime 5 sequenze sia la stessa
        di un equivalente allineamento con solo le stesse sequenze
        """
        chunck = self.chunck
        comp = self.comp
        comp.set_ranges(seq_lists=(range(chunck),))
        comp.calc_comp()
        comp_partial = comp.comp
        alg2 = Alignment()
        for x in xrange(chunck):
            alg2.add_seq(seq=self.alg[x])
        comp2 = NucComposition()
        comp2.alg = alg2
        comp2.calc_comp()
        comp_all = comp2.comp
        self.failUnless(comp_partial == comp_all)


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestComp)
    unittest.TextTestRunner(verbosity=2).run(suite)
