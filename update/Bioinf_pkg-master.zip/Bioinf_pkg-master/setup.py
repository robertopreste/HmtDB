#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Edited by Roberto Preste
from distutils.core import setup
from distutils.extension import Extension
from Pyrex.Distutils import build_ext
import bioinf

# opzioni core2 gcc 4.3
optimizations = ["-mtune=core2", "-march=core2", "-O3", "-funroll-loops", "-ffast-math",
                 "-fomit-frame-pointer", "-pipe", "-mfpmath=sse", "-mssse3"]
# opzioni per pentium 4 gcc 3.4 mingw
# optimizations = ["-march=pentium4", "-O3", "-ffast-math"]
# opzioni generali
# optimizations = ["-march=native", "-O3", "-ffast-math"]

distances = Extension("bioinf.c_distances", ["source/c_distances.c"],
                      extra_compile_args=optimizations)
variability = Extension("bioinf.c_variability", ["source/c_variability.pyx"],
                        extra_compile_args=optimizations)

setup(name="Bioinf",
      version="1.0",
      description="Bioinformatics Tools For SiteVar, edited by Roberto Preste.",
      author="Roberto Preste",
      author_email="roberto.preste@gmail.com",
      packages=["bioinf", "bioinf.files"],
      ext_modules=[distances, variability],
      cmdclass={"build_ext": build_ext})
